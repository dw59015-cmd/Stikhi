package com.lirveyn.stikhi.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "poems")
data class Poem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "Без названия",
    val body: String = "",
    val tags: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
