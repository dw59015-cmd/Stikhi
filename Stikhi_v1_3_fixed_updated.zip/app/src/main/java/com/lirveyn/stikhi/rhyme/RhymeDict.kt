package com.lirveyn.stikhi.rhyme

import com.lirveyn.stikhi.core.TextUtils

object RhymeDict {
    private val seed: MutableMap<String, MutableSet<String>> = mutableMapOf(
        "а" to mset("весна","волна","тропа","трава","луна","душа","вина","страна","тишина"),
        "я" to mset("заря","земля","стезя","семья","змея","струя","моя","твоя"),
        "ой" to mset("герой","покой","прибой","земной","ночной","морской"),
        "ить" to mset("любить","хранить","дарить","творить","простить","забыть"),
        "еть" to mset("гореть","лететь","уметь","суметь","петь"),
        "ать" to mset("молчать","дышать","играть","мечтать","страдать","шептать"),
        "овь" to mset("любовь","кровь"),
        "ет" to mset("свет","рассвет","привет","завет"),
        "онь" to mset("огонь","вонь")
    )

    private val authorLexicon = listOf(
        "природа","свет","тишина","дорога","сердце","любовь","земля","огонь","ночь","дождь","ветер","небо","туман","осень","листва","река","печаль","надежда","шаг","след","голос","кровь","луч","ветви","тропы","ветра"
    )

    init {
        authorLexicon.forEach { w ->
            val key = TextUtils.rhymeKey(w)
            seed.getOrPut(key) { mutableSetOf() }.add(w)
        }
    }

    fun suggest(word: String, corpus: String, limit: Int = 50): List<String> {
        val w = word.trim()
        if (w.isBlank()) return emptyList()
        val key = TextUtils.rhymeKey(w)
        val base = seed[key].orEmpty()
        val fromCorpus = collectFromCorpus(key, corpus)
        return (base + fromCorpus)
            .map { it.trim() }
            .filter { it.isNotBlank() && it.lowercase() != w.lowercase() }
            .distinct()
            .take(limit)
    }

    private fun collectFromCorpus(key: String, corpus: String): List<String> {
        if (key.isBlank()) return emptyList()
        val words = corpus.split(Regex("[^A-Za-zА-Яа-яЁё-]+")).filter { it.isNotBlank() }
        return words.filter { TextUtils.rhymeKey(it) == key }
            .map { it.trim(' ',',','.',';','—','-','!','?','"','\'','«','»',':','(',')') }
            .distinct()
    }

    fun extend(map: Map<String, List<String>>) {
        map.forEach { (k, list) -> seed.getOrPut(k) { mutableSetOf() }.addAll(list) }
    }

    private fun mset(vararg items: String) = items.filter { it.isNotBlank() }.toMutableSet()
}
