package com.lirveyn.stikhi.templates

data class Template(val name: String, val title: String, val body: String)

val QUATRAIN = Template(
    name = "quatrain",
    title = "Четверостишие",
    body = """
        Первая строка — ритм в пути,
        Вторая — тише, мягче, чище,
        Третья — с паузой в груди,
        Четвёртая — как свет сквозящий.
    """.trimIndent()
)

val HAIKU = Template(
    name = "haiku",
    title = "Хокку (5-7-5)",
    body = """
        пять слогов — вдох
        семь слогов — тихий шаг
        пять — свет окна
    """.trimIndent()
)

val SONNET = Template(
    name = "sonnet",
    title = "Сонет (14 строк)",
    body = (1..14).joinToString("\n") { "$it." }
)

val ALL_TEMPLATES = listOf(QUATRAIN, HAIKU, SONNET)
