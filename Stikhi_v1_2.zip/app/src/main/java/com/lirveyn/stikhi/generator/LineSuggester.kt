package com.lirveyn.stikhi.generator
import kotlin.random.Random
class LineSuggester(corpus: String) {
    private val map: MutableMap<String, MutableList<String>> = mutableMapOf()
    init {
        val lines = corpus.lines().map { it.trim() }.filter { it.isNotBlank() }
        for (line in lines) {
            val words = line.split(Regex("\s+")).map { it.lowercase() }
            if (words.size >= 2) for (i in 0 until words.size-1) map.getOrPut(words[i]) { mutableListOf() }.add(words[i+1])
        }
    }
    fun suggestNext(word: String, max: Int = 8): List<String> = map[word.lowercase()].orEmpty().shuffled().take(max)
    fun continueFrom(start: String, maxWords: Int = 8): String {
        val tokens = start.trim().split(Regex("\s+")).toMutableList()
        var cur = tokens.lastOrNull()?.lowercase() ?: return start
        repeat(maxWords) {
            val nexts = map[cur].orEmpty(); if (nexts.isEmpty()) return tokens.joinToString(" ")
            val n = nexts[Random.nextInt(nexts.size)]; tokens.add(n); cur = n
        }
        return tokens.joinToString(" ")
    }
}
