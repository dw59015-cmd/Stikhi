package com.lirveyn.stikhi.rhyme

import com.lirveyn.stikhi.core.TextUtils

object RhymeDict {
    private val seed: MutableMap<String, MutableSet<String>> = mutableMapOf(
        "а" to mset("весна","волна","тропа","трава","луна","душа","страна","вина","вода","звезда","мечта","тоска","рука","берега","тишина","судьба","глубина","гора","река","мгла","земля","роса","юга","даль","печаль"),
        "я" to mset("заря","семья","земля","стезя","змея","струя","судья","моя","твоя","колея"),
        "о" to mset("тепло","добро","окно","зерно","кино","крыло","ядро","дно"),
        "е" to mset("поле","море"),
        "и" to mset("следы","сады","миры","льды"),
        "у" to mset("огню","судьбу","тоску","звезду","струну","весну","вину"),
        "ю" to mset("зарю","люблю","молю","союз"),
        "ой" to mset("герой","покой","прибой","земной","ночной","морской","родной","живой","немой","молодой","голубой","луговой","большой"),
        "ый" to mset("луговый","степной","ручной","земной"),
        "ий" to mset("синий","дальний","тихий","вечный"),
        "ать" to mset("молчать","дышать","играть","мечтать","страдать","сверкать","шептать","обнимать","создавать","зажигать","узнавать"),
        "ять" to mset("стоять","сиять","таять"),
        "еть" to mset("гореть","лететь","уметь","суметь","петь","шуметь","светлеть"),
        "ить" to mset("любить","хранить","дарить","творить","простить","забыть","говорить","молить","светить","пленить"),
        "овь" to mset("любовь","кровь"),
        "ень" to mset("день","тень","лень"),
        "онь" to mset("огонь","звон","вонь"),
        "ель" to mset("метель","капель","цель","колыбель"),
        "есть" to mset("честь","месть","жест","весть"),
        "ость" to mset("радость","сладость","гордость","близкость","нежность","верность"),
        "ение" to mset("видение","сомнение","движение","наступление","исцеление","прощение","спасение","горение","течение"),
        "енье" to mset("горенье","тленье","томленье","биенье"),
        "ание" to mset("сияние","страдание","дыхание","созерцание","желание","признание"),
        "ет" to mset("свет","рассвет","ответ","завет","привет","портрет","след"),
        "ерце" to mset("сердце"),
        "очь" to mset("ночь","прочь"),
        "ождь" to mset("дождь","гвоздь"),
        "ога" to mset("дорога","берлога"),
        "ина" to mset("глубина","вина")
    )

    private val authorLexicon = listOf(
        "природа","свет","тишина","дорога","сердце","любовь","земля","огонь","ночь","дождь","ветер","небо","туман","осень",
        "листва","река","печаль","надежда","шаг","след","голос","луч","ветви","тропы","светло","убежище","дом","остров",
        "молитва","верность","прощение","душа","сила","вера","добро","рассвет","сад","рай","Эдем"
    )

    init {
        authorLexicon.forEach { w ->
            val key = TextUtils.rhymeKey(w)
            seed.getOrPut(key) { mutableSetOf() }.add(w)
        }
    }

    fun suggest(word: String, corpus: String, limit: Int = 50): List<String> {
        val w = word.trim()
        if (w.isBlank()) return emptyList()
        val key = TextUtils.rhymeKey(w)
        val base = seed[key].orEmpty()
        val fromCorpus = collectFromCorpus(key, corpus)
        return (base + fromCorpus)
            .map { it.trim() }
            .filter { it.isNotBlank() and (it != w) }
            .distinct()
            .take(limit)
    }

    private fun collectFromCorpus(key: String, corpus: String): List<String> {
        if (key.isBlank()) return emptyList()
        val words = corpus.split(Regex("[^A-Za-zА-Яа-яЁё-]+")).filter { it.isNotBlank() }
        return words.filter { TextUtils.rhymeKey(it) == key }
            .map { it.trim(' ',',','.',';','—','-','!','?','\"','\'','«','»',':','(',')') }
            .distinct()
    }

    fun extend(map: Map<String, List<String>>) {
        map.forEach { (k, list) ->
            val set = seed.getOrPut(k) { mutableSetOf() }
            set.addAll(list)
        }
    }

    private fun mset(vararg items: String) = items.filter { it.isNotBlank() }.toMutableSet()
}
