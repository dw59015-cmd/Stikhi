# Stikhi (Android)

Офлайн-блокнот для стихов с рифмовником. Сборка в облаке через GitHub Actions.

## Сборка на телефоне (без ноутбука)

1. Скачай ZIP ниже и разархивируй локально **или** сразу залей в новый репозиторий GitHub (через приложение GitHub).
2. В репозитории создай workflow по пути `.github/workflows/android.yml` (см. ниже).
3. Открой вкладку **Actions** → запусти workflow → скачай артефакт APK.

## Workflow (вставить как .github/workflows/android.yml)

```yaml
name: Android CI
on: [workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: '17' }
      - name: Make gradlew executable
        run: chmod +x ./gradlew
      - uses: gradle/gradle-build-action@v3
        with: { arguments: assembleDebug }
      - uses: actions/upload-artifact@v4
        with:
          name: Stikhi-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```
