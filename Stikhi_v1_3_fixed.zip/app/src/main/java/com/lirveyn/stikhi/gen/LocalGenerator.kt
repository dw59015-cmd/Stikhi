package com.lirveyn.stikhi.gen

class LocalGenerator(private val order: Int = 3) {
    private val map = mutableMapOf<String, MutableList<Char>>()
    private val seeds = mutableListOf<String>()

    fun train(text: String) {
        if (text.length <= order) return
        val clean = text.replace(Regex("[\r]"), "")
        for (i in 0..clean.length - order - 1) {
            val key = clean.substring(i, i + order)
            val next = clean[i + order]
            map.getOrPut(key) { mutableListOf() }.add(next)
            if (i == 0 || clean[i - 1] == '\n') seeds.add(key)
        }
        if (seeds.isEmpty()) seeds.add(clean.substring(0, order))
    }

    fun generate(maxChars: Int = 400): String {
        if (map.isEmpty()) return ""
        var key = seeds.random()
        val sb = StringBuilder(key)
        while (sb.length < maxChars) {
            val opts = map[key] ?: break
            val ch = opts.random()
            sb.append(ch)
            key = sb.substring(sb.length - order, sb.length)
        }
        return sb.toString()
    }
}
