package com.lirveyn.stikhi.core
object TextUtils {
    private val vowels = setOf('а','е','ё','и','о','у','ы','э','ю','я','А','Е','Ё','И','О','У','Ы','Э','Ю','Я')
    fun countSyllables(line: String): Int = line.count { it in vowels }
    fun lastWord(line: String): String = line.trim().split(Regex("\s+")).lastOrNull()
        ?.trim(' ',',','.',';','—','-','!','?','"','\'','«','»',':','(',')') ?: ""
    fun rhymeKey(word: String): String {
        if (word.isBlank()) return ""
        val idx = word.indexOfLast { it in vowels }
        return if (idx >= 0 && idx < word.length) word.substring(idx).lowercase() else word.lowercase()
    }
    fun vowelsOf(word: String): String = word.filter { it in vowels }.lowercase()
    fun consonantsOf(word: String): String = word.filter { it !in vowels && it.isLetter() }.lowercase()
    fun rhymeStressType(word: String): RhymeStressType {
        val v = vowelsOf(rhymeKey(word))
        return when (v.length) { 0,1 -> RhymeStressType.MASCULINE; 2 -> RhymeStressType.FEMININE; else -> RhymeStressType.DACTYLIC }
    }
}
enum class RhymeStressType { MASCULINE, FEMININE, DACTYLIC }
