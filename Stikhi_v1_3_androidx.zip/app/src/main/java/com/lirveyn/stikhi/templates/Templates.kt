package com.lirveyn.stikhi.templates
data class Template(val name: String, val title: String, val body: String)
val QUATRAIN = Template("quatrain","Четверостишие",
    '''
Первая строка — ритм в пути,
Вторая — тише, мягче, чище,
Третья — с паузой в груди,
Четвёртая — как свет сквозящий.
'''.trimIndent())
val HAIKU = Template("haiku","Хокку (5-7-5)",
    '''
пять слогов — вдох
семь слогов — тихий шаг
пять — свет окна
'''.trimIndent())
val SONNET = Template("sonnet","Сонет (14 строк)", (1..14).joinToString("\n") { "$it." })
val ALL_TEMPLATES = listOf(QUATRAIN, HAIKU, SONNET)
