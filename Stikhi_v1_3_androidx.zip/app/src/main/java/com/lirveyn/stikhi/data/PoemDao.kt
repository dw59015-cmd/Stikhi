package com.lirveyn.stikhi.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface PoemDao {
    @Query("SELECT * FROM poems ORDER BY updatedAt DESC") fun observeAll(): Flow<List<Poem>>
    @Query("SELECT * FROM poems WHERE id = :id") fun observeById(id: Long): Flow<Poem?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(poem: Poem): Long
    @Delete suspend fun delete(poem: Poem)
}
