package com.lirveyn.stikhi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lirveyn.stikhi.templates.ALL_TEMPLATES
import com.lirveyn.stikhi.templates.Template
@Composable
fun TemplatesScreen(onPick: (Template) -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Шаблоны", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn { items(ALL_TEMPLATES) { tpl ->
            ElevatedCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(tpl.title, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(tpl.body.take(120) + if (tpl.body.length > 120) "…" else "")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onPick(tpl) }) { Text("Вставить в мои стихи") }
                }
            }
        } }
    }
}
