package com.lirveyn.stikhi
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.room.Room
import com.lirveyn.stikhi.core.TextUtils
import com.lirveyn.stikhi.data.AppDb
import com.lirveyn.stikhi.data.Poem
import com.lirveyn.stikhi.rhyme.RhymeDict
import com.lirveyn.stikhi.generator.LineSuggester
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val db = Room.databaseBuilder(applicationContext, AppDb::class.java, "stikhi.db").build()
                @Suppress("UNCHECKED_CAST") return MainVm(db) as T
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AppRoot(vm) } }
}
enum class Dest(val route: String) { List("list"), Edit("edit"), Templates("templates") }

@Composable fun AppRoot(vm: MainVm) {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("Stikhi — офлайн") }) }) { inner ->
            NavHost(nav, startDestination = Dest.List.route, Modifier.padding(inner)) {
                composable(Dest.List.route) { ListScreen(vm, onAdd = { vm.newPoem { id -> nav.navigate("${Dest.Edit.route}/$id") } }, onOpen = { id -> nav.navigate("${Dest.Edit.route}/$id") }) }
                composable("${Dest.Edit.route}/{id}") { back -> val id = back.arguments?.getString("id")?.toLongOrNull() ?: -1; EditorScreen(vm, id) }
                composable(Dest.Templates.route) { TemplatesScreen(onPick = { vm.insertTemplate(it) }) }
            }
        }
    }
}

@Composable private fun ListScreen(vm: MainVm, onAdd: () -> Unit, onOpen: (Long) -> Unit) {
    val poems by vm.poems.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAdd) { Text("Новый стих") }
            OutlinedButton(onClick = { /* TODO navigate templates */ }) { Text("Шаблоны") }
        }
        Divider()
        LazyColumn(Modifier.fillMaxSize()) {
            items(poems) { p ->
                ListItem(
                    headlineContent = { Text(p.title, fontWeight = FontWeight.SemiBold) },
                    supportingContent = { Text("Строк: ${p.body.lines().size}") },
                    modifier = Modifier.clickable { onOpen(p.id) }
                )
                Divider()
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun EditorScreen(vm: MainVm, poemId: Long) {
    val state by vm.observePoem(poemId).collectAsState(null)
    val allPoems by vm.poems.collectAsState()
    var title by remember(state?.title) { mutableStateOf(TextFieldValue(state?.title ?: "")) }
    var body by remember(state?.body) { mutableStateOf(TextFieldValue(state?.body ?: "")) }

    fun insertAtCursor(w: String) {
        val sel = body.selection; val t = body.text
        val start = sel.start.coerceIn(0, t.length); val end = sel.end.coerceIn(0, t.length)
        val prefix = if (start>0 && !t[start-1].isWhitespace()) " " else ""
        val newText = t.replaceRange(start, end, prefix + w)
        val newCursor = (start + prefix.length + w.length)
        body = TextFieldValue(newText, selection = androidx.compose.ui.text.TextRange(newCursor))
        vm.updateBody(poemId, newText)
    }

    val lastLine = remember(body.text) { body.text.substringAfterLast("\n", body.text) }
    val lastWord = remember(lastLine) { TextUtils.lastWord(lastLine) }
    val corpus = remember(allPoems) { allPoems.joinToString("\n") { it.body } }
    val suggester = remember(corpus) { LineSuggester(corpus) }
    val candidates = remember(lastWord, corpus) { if (lastWord.isNotBlank()) suggester.suggestNext(lastWord, 8) else emptyList() }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(value = title, onValueChange = { title = it; vm.updateTitle(poemId, it.text) }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = body, onValueChange = { body = it; vm.updateBody(poemId, it.text) }, label = { Text("Текст стиха") }, modifier = Modifier.weight(1f).fillMaxWidth(), minLines = 10)
        StatsPanel(text = body.text)
        RhymeHelper(target = lastWord, corpus = corpus, onInsert = { insertAtCursor(it) })
        if (candidates.isNotEmpty()) {
            Text("Предложить строку", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                candidates.forEach { w -> AssistChip(onClick = { insertAtCursor(" "+w) }, label = { Text(w) }) }
            }
        }
    }
}

@Composable private fun StatsPanel(text: String) {
    val lines = text.lines()
    val syll = remember(text) { lines.map { TextUtils.countSyllables(it) } }
    val rhymeKeys = remember(text) { lines.map { TextUtils.rhymeKey(TextUtils.lastWord(it)) } }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Строк: ${lines.size} • Слов: ${text.split(Regex("\s+")).filter { it.isNotBlank() }.size}")
            Divider()
            lines.forEachIndexed { idx, line ->
                val key = rhymeKeys[idx]
                Text("${idx + 1}. (${syll[idx]})  ${line}")
                if (key.isNotBlank()) Text("   рифм. ключ: $key", style = MaterialTheme.typography.labelSmall)
            }
            Text("*Слоги считаются по гласным (эвристика). Рифма — от последней гласной.", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun RhymeHelper(target: String, corpus: String, onInsert: (String) -> Unit) {
    var word by remember(target) { mutableStateOf(TextFieldValue(target)) }
    val all = remember(word.text, corpus) { RhymeDict.suggest(word.text, corpus, 200) }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Рифмовник", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(value = word, onValueChange = { word = it }, label = { Text("Слово для рифмы") }, singleLine = true)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                all.forEach { s -> ElevatedAssistChip(onClick = { onInsert(s) }, label = { Text(s) }) }
            }
        }
    }
}

class MainVm(private val db: AppDb) : ViewModel() {
    private val dao = db.poemDao()
    val poems: StateFlow<List<Poem>> = dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun observePoem(id: Long): StateFlow<Poem?> = dao.observeById(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    fun newPoem(after: (Long) -> Unit) = viewModelScope.launch(Dispatchers.IO) { val id = dao.upsert(Poem()); after(id) }
    fun updateTitle(id: Long, title: String) = viewModelScope.launch(Dispatchers.IO) {
        poems.value.find { it.id == id }?.let { dao.upsert(it.copy(title = title, updatedAt = System.currentTimeMillis())) }
    }
    fun updateBody(id: Long, body: String) = viewModelScope.launch(Dispatchers.IO) {
        poems.value.find { it.id == id }?.let { dao.upsert(it.copy(body = body, updatedAt = System.currentTimeMillis())) }
    }
    fun delete(id: Long) = viewModelScope.launch(Dispatchers.IO) { poems.value.find { it.id == id }?.let { dao.delete(it) } }
    fun insertTemplate(tpl: com.lirveyn.stikhi.templates.Template) = viewModelScope.launch(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        dao.upsert(Poem(title = tpl.title, body = tpl.body, tags = "template:${tpl.name}", createdAt = now, updatedAt = now))
    }
}
